import numpy as np
import pandas as pd
import random
import tensorflow as tf

from sklearn.utils import shuffle

seq_sim_matrix = pd.read_csv("E:\github源码\MDA-AENMF-main - 副本\mydata\data\disease_GIP_similarity - 副本.csv", index_col=0, dtype=np.float32).to_numpy()
seq_sim_matrix = seq_sim_matrix.transpose()
print(seq_sim_matrix)
a = seq_sim_matrix.shape[0]
b = seq_sim_matrix.shape[1]
print(a, b)

N = np.sum(seq_sim_matrix)
col1 = []  # Used to calculate probability P

# Calculate the first formula
for i in range(b):
    c = np.sum(seq_sim_matrix[:, i])
    col1.append(c / N)

col1 = np.array(col1)

metabolite_entropy_list = []

for i in range(a):
    sum_entropy = 0
    for j in range(b):
        if seq_sim_matrix[i][j] != 0:
            sum_entropy += (col1[j] * np.log2(col1[j]))
    sum_entropy = -sum_entropy
    metabolite_entropy_list.append(sum_entropy)

metabolite_entropy_list = np.array(metabolite_entropy_list)

res = np.zeros((a, a))

for i in range(a):
    for j in range(a):
        sum_value = 0
        if i == j:
            res[i][j] = 1
        else:
            for k in range(b):
                if seq_sim_matrix[i][k] == 1 and seq_sim_matrix[j][k] == 1:
                    sum_value += (col1[k] * np.log2(col1[k]))
            sum_value = -sum_value
            res[i][j] = 2 * sum_value / (metabolite_entropy_list[i] + metabolite_entropy_list[j])

        # Print and save with two decimal places
        print(i, j, round(res[i][j], 2))

# Create a DataFrame and save to a CSV file
pred_score = pd.DataFrame(res)
pred_score.to_csv("result_disease_entropy.csv", index=False)