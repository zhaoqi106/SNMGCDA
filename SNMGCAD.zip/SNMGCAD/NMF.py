import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
# from feature_connect1 import *
# from multi_head_attention import *

import time


# 该函数用来获取标签、拼接特征
def Feature_processing(D, train_samples, feature_d, feature_c, feature_MFc, feature_MFd):
    vect_len1 = feature_d.shape[1]
    vect_len2 = feature_c.shape[1]
    NMF_feature_c = feature_MFc.shape[0]  # 271
    NMF_feature_d = feature_MFd.shape[0]
    NMF_feature_len = NMF_feature_c + NMF_feature_d
    train_n = train_samples.shape[0]
    NMF_len = int((feature_MFc.shape[0] + feature_MFd.shape[0]) / NMF_feature_len)
    train_feature = torch.zeros((train_n, D + vect_len1), dtype=torch.float32)
    train_label = np.zeros([train_n])
    start_time = time.time()
    for i in range(train_n):
        vec1 = feature_d[train_samples[i, 0], :]
        vec2 = feature_c[218 * train_samples[i, 0] + train_samples[i, 1], :]
        vec3 = feature_MFc[train_samples[i, 0]] * feature_MFd[train_samples[i, 1]]
        vec3 = torch.tensor(vec3, requires_grad=True)
        vec4 = torch.mul(vec1, vec2)
        train_feature[i, 0:vect_len1 + D] = torch.cat((vec4, vec3), dim=0)
        train_label[i] = train_samples[i, 2]
    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Run time：{elapsed_time} s")
    return train_feature, train_label


def get_low_feature(k, lam, th, A):
    m, n = A.shape
    print(m, n)
    arr1 = np.random.randint(0, 100, size=(m, k))  # (271,180)
    U = arr1 / 100
    arr2 = np.random.randint(0, 100, size=(k, n))  # # (180,218)
    V = arr2 / 100
    obj_value = objective_function(A, A, U, V, lam)
    obj_value1 = obj_value + 1
    i = 0
    diff = abs(obj_value1 - obj_value)
    epoch = 500
    while i < epoch:
        i = i + 1
        U = updating_U(A, A, U, V, lam)
        V = updating_V(A, A, U, V, lam)

    return U, V.transpose()


def objective_function(W, A, U, V, lam):
    m, n = A.shape
    sum_obj = 0
    for i in range(m):
        for j in range(n):
            sum_obj = sum_obj + W[i, j] * (A[i, j] - U[i, :].dot(V[:, j])) + lam * (
                    np.linalg.norm(U[i, :], ord=1, keepdims=False) + np.linalg.norm(V[:, j], ord=1, keepdims=False))
    return sum_obj


def updating_U(W, A, U, V, lam):
    m, n = U.shape
    upper = (W * A).dot(V.T)
    down = (W * (U.dot(V))).dot((V.T)) + (lam / 2) * (np.ones([m, n]))
    U_new = U
    for i in range(m):
        for j in range(n):
            U_new[i, j] = U[i, j] * (upper[i, j] / down[i, j])
    return U_new


def updating_V(W, A, U, V, lam):
    m, n = V.shape
    upper = (U.T).dot(W * A)
    down = (U.T).dot(W * (U.dot(V))) + (lam / 2) * (np.ones([m, n]))
    V_new = V
    for i in range(m):
        for j in range(n):
            V_new[i, j] = V[i, j] * (upper[i, j] / down[i, j])
    return V_new


