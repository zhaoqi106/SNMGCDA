# run main.py to run our model 

# requirement

numpy                     1.19.5                             

python                    3.6.13               

scikit-learn              0.23.2        

scipy                     1.5.4       

torch                     1.8.0+cu111

torchvision               0.9.0+cu111  



