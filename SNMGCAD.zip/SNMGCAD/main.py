import itertools
from sklearn.metrics import roc_curve, auc,precision_recall_curve
from scipy import interp
from classifiers import *
from NMF import *
from Sparse_AE import *
import warnings
from graph_feature import *
from metric import get_metrics

warnings.filterwarnings("ignore")

# parameter
n_splits = 5
classifier_epochs = 50
m_threshold = [0.7]
epochs = [200]
fold = 0
result = np.zeros((1, 7), float)
tprs = []
aucs = []
# mean_fpr = np.linspace(0, 1, 100)
mean_fpr = np.linspace(0, 1, 100)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

for s in itertools.product(m_threshold, epochs):

    association = pd.read_csv("mydata/data1/association.csv", index_col=0).to_numpy()
    samples = get_all_samples(association)

    knn1 = 27
    knn2 = 21
    c_fusion_sim, d_fusion_sim = get_fusion_sim(knn1, knn2)  # Integration of similarity networks for CircRNA or Drug
    kf = KFold(n_splits=n_splits, shuffle=True)
    # CircRNA and Drug features extraction from NMF
    D = 128
    # get NMF feature
    NMF_cfeature, NMF_dfeature = get_low_feature(D, 0.01, pow(10, -4), association)

    for train_index, val_index in kf.split(samples):
        fold += 1
        train_samples = samples[train_index, :]
        val_samples = samples[val_index, :]
        new_association = association.copy()
        for i in val_samples:
            new_association[i[0], i[1]] = 0

        # CircRNA features extraction from muti-head graph attention encoder
        c_features = graph_feature(c_fusion_sim.shape[0], c_fusion_sim, new_association, train_samples, val_samples)
        print("graph_feature is finshed!")

        # Drug features extraction from SparseAutoencoder
        d_features = Sparse_Auto_encoder(d_fusion_sim)  # 59078,64
        # pd.DataFrame(d_features).to_csv('./pre_data/d_features.csv')
        print("AutoEncoder is finshed!")

        # get feature and label
        train_feature, train_label = Feature_processing(D, train_samples, c_features, d_features, NMF_cfeature,
                                                        NMF_dfeature)

        val_feature, val_label = Feature_processing(D, val_samples, c_features, d_features, NMF_cfeature, NMF_dfeature)

        # MLP classfier
        model = BuildModel(train_feature, train_label)

        val_feature_tensor = torch.tensor(val_feature, dtype=torch.float32)
        model.eval()
        with torch.no_grad():
            # Make predictions using the trained model
            y_score_tensor = model(val_feature_tensor)

        # Convert the PyTorch tensor to a NumPy array and extract the first column
        y_score = y_score_tensor.numpy()[:, 0]
        # calculate metrics
        fpr, tpr, thresholds = roc_curve(val_label, y_score)


        tprs.append(interp(mean_fpr, fpr, tpr))
        tprs[-1][0] = 0.0
        roc_auc = auc(fpr, tpr)
        aucs.append(roc_auc)


        mean_auc = auc(fpr, tpr)

        result += get_metrics(val_label, y_score)
        print('[auc, aupr, f1_score, accuracy, recall, specificity, precision]',
              get_metrics(val_label, y_score))

    print("==================================================")
    res_all = result / n_splits
    print("auc:%f, aupr:%f, f1_score:%f, accuracy:%f, recall:%f, specificity:%f, precision:%f" %
          (res_all[0][0], res_all[0][1], res_all[0][2], res_all[0][3], res_all[0][4], res_all[0][5], res_all[0][6]))

    # plot ROC curve
    plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='g', label='diagonal', alpha=.8)
    mean_tpr = np.mean(tprs, axis=0)
    mean_tpr[-1] = 1.0
    plt.plot(mean_fpr, mean_tpr, color='r', label=r'SNMGCAD ROC (area=%0.4f)' % mean_auc, lw=2, alpha=.8)
    std_tpr = np.std(tprs, axis=0)
    tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
    tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
    plt.fill_between(mean_fpr, tprs_lower, tprs_upper, color='gray', alpha=.2)
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC')
    plt.legend(loc='lower right')
    plt.show()
